const exampleList = ["TEA","EAT","TEE","PEA","PET","APE"];
const word = {
    exampleList
}

module.exports = word;